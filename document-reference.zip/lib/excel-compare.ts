import * as XLSX from 'xlsx'
import { unzipSync, strFromU8 } from 'fflate'

export type Severity = 'critical' | 'major' | 'minor'
export type Category =
  | 'structure'
  | 'keydata'
  | 'formula'
  | 'layout'
  | 'content'
  | 'headerfooter'

export interface Difference {
  id: string
  category: Category
  severity: Severity
  sheet: string
  cell?: string
  title: string
  masterValue: string
  actualValue: string
  detail: string
}

export interface CategorySummary {
  key: Category
  label: string
  total: number
  critical: number
  major: number
  minor: number
}

export interface FileMeta {
  name: string
  size: number
  sheetCount: number
  sheetNames: string[]
}

export interface CompareResult {
  status: 'PASS' | 'FAIL'
  durationMs: number
  totalDiffs: number
  criticalCount: number
  majorCount: number
  minorCount: number
  differences: Difference[]
  categories: CategorySummary[]
  master: FileMeta
  actual: FileMeta
  checkedAt: string
}

interface CellData {
  v: string
  f?: string
  isNumber: boolean
}

interface HeaderFooterSlot {
  left: string
  center: string
  right: string
  raw: string
}

interface HeaderFooter {
  header: HeaderFooterSlot
  footer: HeaderFooterSlot
}

interface SheetData {
  name: string
  rows: number
  cols: number
  merges: string[]
  cells: Map<string, CellData>
  headerFooter: HeaderFooter
}

interface WorkbookData {
  sheetNames: string[]
  sheets: Map<string, SheetData>
}

const KEY_DATA_KEYWORDS = [
  'form no',
  'form number',
  'doc no',
  'document no',
  'document number',
  'revision',
  'rev.',
  'rev no',
  'effective',
  'issue date',
  'เอกสารเลขที่',
  'หมายเลขเอกสาร',
  'รหัสเอกสาร',
  'แก้ไขครั้งที่',
  'ครั้งที่แก้ไข',
  'วันที่บังคับใช้',
  'วันที่มีผล',
  'วันที่ประกาศใช้',
]

const CATEGORY_LABELS: Record<Category, string> = {
  structure: 'โครงสร้างไฟล์',
  keydata: 'ข้อมูลสำคัญ',
  formula: 'สูตรคำนวณ',
  layout: 'Layout / ตำแหน่ง',
  content: 'ข้อความในแบบฟอร์ม',
  headerfooter: 'หัวกระดาษ / ท้ายกระดาษ',
}

export function getCategoryLabel(key: Category): string {
  return CATEGORY_LABELS[key]
}

const EMPTY_SLOT: HeaderFooterSlot = { left: '', center: '', right: '', raw: '' }

// Decode Excel's &L/&C/&R header-footer string into readable segments.
// Strips font/format codes (&"..", &B, &I, &U, &size, &K...) but keeps
// meaningful placeholders (&P page, &N total, &D date, &T time, &F file, &A sheet).
function decodeHeaderFooter(raw: string): HeaderFooterSlot {
  if (!raw) return { ...EMPTY_SLOT }
  const parts: Record<'L' | 'C' | 'R', string> = { L: '', C: '', R: '' }
  let section: 'L' | 'C' | 'R' = 'C' // default section when none specified
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i]
    if (ch === '&') {
      const next = raw[i + 1]
      if (next === 'L' || next === 'C' || next === 'R') {
        section = next
        i++
        continue
      }
      if (next === '"') {
        // &"Font,Style" - skip to closing quote
        const close = raw.indexOf('"', i + 2)
        i = close === -1 ? raw.length : close
        continue
      }
      if (next === 'P') { parts[section] += '[หน้า]'; i++; continue }
      if (next === 'N') { parts[section] += '[จำนวนหน้า]'; i++; continue }
      if (next === 'D') { parts[section] += '[วันที่]'; i++; continue }
      if (next === 'T') { parts[section] += '[เวลา]'; i++; continue }
      if (next === 'F') { parts[section] += '[ชื่อไฟล์]'; i++; continue }
      if (next === 'A') { parts[section] += '[ชื่อชีต]'; i++; continue }
      if (next === 'Z') { parts[section] += '[พาธ]'; i++; continue }
      if (next === 'G') { parts[section] += '[รูปภาพ]'; i++; continue }
      if (next === '&') { parts[section] += '&'; i++; continue }
      if (next === 'K') { i += 7; continue } // &Krrggbb color
      if (next && /[0-9]/.test(next)) {
        // font size digits
        let j = i + 1
        while (j < raw.length && /[0-9]/.test(raw[j])) j++
        i = j - 1
        continue
      }
      // &B &I &U &S &O &H &E &X &Y and others: formatting toggles, skip
      i++
      continue
    }
    parts[section] += ch
  }
  return {
    left: parts.L.trim(),
    center: parts.C.trim(),
    right: parts.R.trim(),
    raw,
  }
}

// Read real print Header/Footer per sheet by unzipping the xlsx and reading
// the <headerFooter> node from each worksheet XML. SheetJS community edition
// does not preserve these, so we parse the OOXML directly.
function parseHeaderFooters(bytes: Uint8Array): Map<string, HeaderFooter> {
  const result = new Map<string, HeaderFooter>()
  let files: Record<string, Uint8Array>
  try {
    files = unzipSync(bytes)
  } catch {
    return result
  }

  const wbXml = files['xl/workbook.xml']
  const relsXml = files['xl/_rels/workbook.xml.rels']
  if (!wbXml || !relsXml) return result

  const wbStr = strFromU8(wbXml)
  const relsStr = strFromU8(relsXml)

  // rId -> target path
  const relMap = new Map<string, string>()
  for (const m of relsStr.matchAll(/<Relationship\b[^>]*\/?>/g)) {
    const tag = m[0]
    const id = /Id="([^"]+)"/.exec(tag)?.[1]
    const target = /Target="([^"]+)"/.exec(tag)?.[1]
    if (id && target) relMap.set(id, target.replace(/^\/?xl\//, '').replace(/^\.\//, ''))
  }

  // sheet name -> rId (r:id)
  for (const m of wbStr.matchAll(/<sheet\b[^>]*\/?>/g)) {
    const tag = m[0]
    const name = /name="([^"]*)"/.exec(tag)?.[1]
    const rid = /r:id="([^"]+)"/.exec(tag)?.[1]
    if (!name || !rid) continue
    const target = relMap.get(rid)
    if (!target) continue
    const path = target.startsWith('worksheets/') ? `xl/${target}` : `xl/${target}`
    const sheetBytes = files[path] ?? files[`xl/${target.replace(/^xl\//, '')}`]
    if (!sheetBytes) continue

    const xml = strFromU8(sheetBytes)
    const hfBlock = /<headerFooter[\s\S]*?<\/headerFooter>/.exec(xml)?.[0] ?? ''
    const pick = (tagName: string) => {
      const re = new RegExp(`<${tagName}[^>]*>([\\s\\S]*?)</${tagName}>`)
      const v = re.exec(hfBlock)?.[1] ?? ''
      return v.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    }
    // prefer odd (default), fall back to first-page variants
    const headerRaw = pick('oddHeader') || pick('firstHeader') || pick('evenHeader')
    const footerRaw = pick('oddFooter') || pick('firstFooter') || pick('evenFooter')

    result.set(name, {
      header: decodeHeaderFooter(headerRaw),
      footer: decodeHeaderFooter(footerRaw),
    })
  }

  return result
}

function parseWorkbook(buf: ArrayBuffer): WorkbookData {
  const bytes = new Uint8Array(buf)
  const wb = XLSX.read(buf, { type: 'array', cellFormula: true, cellNF: false })
  const headerFooters = parseHeaderFooters(bytes)
  const sheets = new Map<string, SheetData>()

  for (const name of wb.SheetNames) {
    const ws = wb.Sheets[name]
    const cells = new Map<string, CellData>()
    let rows = 0
    let cols = 0

    if (ws['!ref']) {
      const range = XLSX.utils.decode_range(ws['!ref'])
      rows = range.e.r - range.s.r + 1
      cols = range.e.c - range.s.c + 1
    }

    const merges = (ws['!merges'] ?? []).map((m) => XLSX.utils.encode_range(m))

    for (const addr of Object.keys(ws)) {
      if (addr.startsWith('!')) continue
      const cell = ws[addr] as XLSX.CellObject
      const raw = cell.v
      if (raw === undefined || raw === null || raw === '') {
        if (!cell.f) continue
      }
      const isNumber = typeof raw === 'number'
      cells.set(addr, {
        v: raw === undefined || raw === null ? '' : String(raw).trim(),
        f: cell.f ? String(cell.f) : undefined,
        isNumber,
      })
    }

    sheets.set(name, {
      name,
      rows,
      cols,
      merges,
      cells,
      headerFooter: headerFooters.get(name) ?? { header: { ...EMPTY_SLOT }, footer: { ...EMPTY_SLOT } },
    })
  }

  return { sheetNames: wb.SheetNames, sheets }
}

function isKeyData(text: string): boolean {
  const lower = text.toLowerCase()
  return KEY_DATA_KEYWORDS.some((kw) => lower.includes(kw))
}

let idCounter = 0
function nextId(): string {
  idCounter += 1
  return `diff-${idCounter}`
}

function fileMeta(name: string, size: number, wb: WorkbookData): FileMeta {
  return {
    name,
    size,
    sheetCount: wb.sheetNames.length,
    sheetNames: wb.sheetNames,
  }
}

export async function compareWorkbooks(
  masterFile: File,
  actualFile: File,
): Promise<CompareResult> {
  const start = performance.now()
  idCounter = 0

  const [masterBuf, actualBuf] = await Promise.all([
    masterFile.arrayBuffer(),
    actualFile.arrayBuffer(),
  ])

  const master = parseWorkbook(masterBuf)
  const actual = parseWorkbook(actualBuf)
  const diffs: Difference[] = []

  // 1. Sheet count / names
  if (master.sheetNames.length !== actual.sheetNames.length) {
    diffs.push({
      id: nextId(),
      category: 'structure',
      severity: 'critical',
      sheet: '—',
      title: 'จำนวน Sheet ไม่ตรงกัน',
      masterValue: `${master.sheetNames.length} sheet`,
      actualValue: `${actual.sheetNames.length} sheet`,
      detail: 'จำนวนชีตในแบบฟอร์มที่ใช้งานจริงไม่ตรงกับ Master Form',
    })
  }

  for (const name of master.sheetNames) {
    if (!actual.sheets.has(name)) {
      diffs.push({
        id: nextId(),
        category: 'structure',
        severity: 'critical',
        sheet: name,
        title: 'Sheet หายไป',
        masterValue: name,
        actualValue: '(ไม่พบ)',
        detail: `ไม่พบ Sheet "${name}" ในแบบฟอร์มที่ใช้งานจริง`,
      })
    }
  }

  for (const name of actual.sheetNames) {
    if (!master.sheets.has(name)) {
      diffs.push({
        id: nextId(),
        category: 'structure',
        severity: 'major',
        sheet: name,
        title: 'Sheet เกินมา',
        masterValue: '(ไม่มีใน Master)',
        actualValue: name,
        detail: `พบ Sheet "${name}" ที่ไม่มีอยู่ใน Master Form`,
      })
    }
  }

  // 2. Per common-sheet comparison
  for (const name of master.sheetNames) {
    const ms = master.sheets.get(name)
    const as = actual.sheets.get(name)
    if (!ms || !as) continue

    // Dimensions
    if (ms.rows !== as.rows) {
      diffs.push({
        id: nextId(),
        category: 'structure',
        severity: 'major',
        sheet: name,
        title: 'จำนวนแถว (Row) ไม่ตรงกัน',
        masterValue: `${ms.rows} แถว`,
        actualValue: `${as.rows} แถว`,
        detail: 'มีการเพิ่ม/ลบแถวเมื่อเทียบกับ Master Form',
      })
    }
    if (ms.cols !== as.cols) {
      diffs.push({
        id: nextId(),
        category: 'structure',
        severity: 'major',
        sheet: name,
        title: 'จำนวนคอลัมน์ (Column) ไม่ตรงกัน',
        masterValue: `${ms.cols} คอลัมน์`,
        actualValue: `${as.cols} คอลัมน์`,
        detail: 'มีการเพิ่ม/ลบคอลัมน์เมื่อเทียบกับ Master Form',
      })
    }

    // Merged cells (layout)
    const masterMerges = new Set(ms.merges)
    const actualMerges = new Set(as.merges)
    for (const m of ms.merges) {
      if (!actualMerges.has(m)) {
        diffs.push({
          id: nextId(),
          category: 'layout',
          severity: 'major',
          sheet: name,
          cell: m,
          title: 'Merged cell หายไป',
          masterValue: m,
          actualValue: '(ไม่ถูกผสาน)',
          detail: 'พื้นที่ผสานเซลล์ (merge) ในต้นฉบับถูกยกเลิกในแบบฟอร์มจริง',
        })
      }
    }
    for (const m of as.merges) {
      if (!masterMerges.has(m)) {
        diffs.push({
          id: nextId(),
          category: 'layout',
          severity: 'minor',
          sheet: name,
          cell: m,
          title: 'Merged cell เพิ่มเข้ามา',
          masterValue: '(ไม่ผสานใน Master)',
          actualValue: m,
          detail: 'มีการผสานเซลล์เพิ่มเติมที่ไม่มีใน Master Form',
        })
      }
    }

    // Print Header / Footer comparison (document control area)
    const hfSlots: { slot: 'header' | 'footer'; label: string }[] = [
      { slot: 'header', label: 'หัวกระดาษ (Header)' },
      { slot: 'footer', label: 'ท้ายกระดาษ (Footer)' },
    ]
    const posLabels: Record<'left' | 'center' | 'right', string> = {
      left: 'ซ้าย',
      center: 'กลาง',
      right: 'ขวา',
    }
    for (const { slot, label } of hfSlots) {
      const mHF = ms.headerFooter[slot]
      const aHF = as.headerFooter[slot]
      for (const pos of ['left', 'center', 'right'] as const) {
        const mv = mHF[pos]
        const av = aHF[pos]
        if (mv === av) continue
        const isControl = isKeyData(mv) || isKeyData(av)
        diffs.push({
          id: nextId(),
          category: 'headerfooter',
          severity: isControl ? 'critical' : 'major',
          sheet: name,
          cell: `${label} · ${posLabels[pos]}`,
          title: isControl
            ? 'ข้อมูลควบคุมใน Header/Footer ไม่ตรงกัน'
            : `${label} ไม่ตรงกัน`,
          masterValue: mv || '(ว่าง)',
          actualValue: av || '(ว่าง)',
          detail: isControl
            ? 'ข้อความควบคุมเอกสาร (Form No./Revision/วันที่) ในหัว-ท้ายกระดาษที่ใช้พิมพ์ไม่ตรงกับต้นฉบับ'
            : 'ข้อความในหัว-ท้ายกระดาษสำหรับพิมพ์ถูกแก้ไขจากต้นฉบับ',
        })
      }
    }

    // Cell-level comparison
    const addresses = new Set<string>([...ms.cells.keys(), ...as.cells.keys()])
    for (const addr of addresses) {
      const mc = ms.cells.get(addr)
      const ac = as.cells.get(addr)

      // Present in master only -> fixed content removed
      if (mc && !ac) {
        if (mc.f) {
          diffs.push({
            id: nextId(),
            category: 'formula',
            severity: 'critical',
            sheet: name,
            cell: addr,
            title: 'สูตรถูกลบ',
            masterValue: `=${mc.f}`,
            actualValue: '(ว่าง)',
            detail: 'เซลล์ที่ควรมีสูตรคำนวณถูกลบออก',
          })
        } else if (!mc.isNumber && mc.v) {
          diffs.push({
            id: nextId(),
            category: isKeyData(mc.v) ? 'keydata' : 'content',
            severity: 'major',
            sheet: name,
            cell: addr,
            title: 'ข้อความ/หัวข้อถูกลบ',
            masterValue: mc.v,
            actualValue: '(ว่าง)',
            detail: 'ข้อความตายตัวในแบบฟอร์มต้นฉบับหายไป',
          })
        }
        continue
      }

      // Present in actual only
      if (!mc && ac) {
        if (ac.f) {
          diffs.push({
            id: nextId(),
            category: 'formula',
            severity: 'major',
            sheet: name,
            cell: addr,
            title: 'สูตรถูกเพิ่มใหม่',
            masterValue: '(ไม่มีสูตร)',
            actualValue: `=${ac.f}`,
            detail: 'มีการเพิ่มสูตรคำนวณที่ไม่มีอยู่ใน Master Form',
          })
        }
        // Empty-in-master + value-in-actual = user-entered data -> ignore
        continue
      }

      if (!mc || !ac) continue

      // Both present -> compare formula first
      const mf = mc.f
      const af = ac.f
      if (mf || af) {
        if (mf && af && mf.replace(/\s/g, '') !== af.replace(/\s/g, '')) {
          diffs.push({
            id: nextId(),
            category: 'formula',
            severity: 'critical',
            sheet: name,
            cell: addr,
            title: 'สูตรถูกแก้ไข',
            masterValue: `=${mf}`,
            actualValue: `=${af}`,
            detail: 'สูตรคำนวณในเซลล์ถูกเปลี่ยนแปลง อาจทำให้ผลลัพธ์คลาดเคลื่อน',
          })
        } else if (mf && !af) {
          diffs.push({
            id: nextId(),
            category: 'formula',
            severity: 'critical',
            sheet: name,
            cell: addr,
            title: 'สูตรถูกแทนที่ด้วยค่าคงที่',
            masterValue: `=${mf}`,
            actualValue: ac.v || '(ค่าคงที่)',
            detail: 'สูตรถูกแทนที่ด้วยการพิมพ์ค่าเองแทนการคำนวณ',
          })
        } else if (!mf && af) {
          diffs.push({
            id: nextId(),
            category: 'formula',
            severity: 'major',
            sheet: name,
            cell: addr,
            title: 'มีการเพิ่มสูตรทับค่าเดิม',
            masterValue: mc.v || '(ค่าคงที่)',
            actualValue: `=${af}`,
            detail: 'ค่าคงที่ในต้นฉบับถูกเปลี่ยนเป็นสูตรคำนวณ',
          })
        }
        continue
      }

      // Both are plain values. Only flag TEXT/label cells that changed.
      if (mc.v === ac.v) continue

      if (!mc.isNumber && mc.v) {
        const key = isKeyData(mc.v)
        diffs.push({
          id: nextId(),
          category: key ? 'keydata' : 'content',
          severity: key ? 'critical' : 'major',
          sheet: name,
          cell: addr,
          title: key ? 'ข้อมูลควบคุมเอกสารไม่ตรงกัน' : 'ข้อความในแบบฟอร์มถูกแก้ไข',
          masterValue: mc.v,
          actualValue: ac.v || '(ว่าง)',
          detail: key
            ? 'Form No. / Revision / Effective date หรือข้อมูลควบคุมไม่ตรงกับเอกสารที่ขึ้นทะเบียน'
            : 'ข้อความตายตัวในแบบฟอร์มถูกเปลี่ยนแปลงจากต้นฉบับ',
        })
      }
      // Numeric differences in template cells are treated as data entry -> ignore
    }
  }

  // Severity ordering for display
  const order: Record<Severity, number> = { critical: 0, major: 1, minor: 2 }
  diffs.sort((a, b) => order[a.severity] - order[b.severity])

  const criticalCount = diffs.filter((d) => d.severity === 'critical').length
  const majorCount = diffs.filter((d) => d.severity === 'major').length
  const minorCount = diffs.filter((d) => d.severity === 'minor').length

  const categoryKeys: Category[] = [
    'structure',
    'keydata',
    'formula',
    'layout',
    'headerfooter',
    'content',
  ]
  const categories: CategorySummary[] = categoryKeys.map((key) => {
    const items = diffs.filter((d) => d.category === key)
    return {
      key,
      label: CATEGORY_LABELS[key],
      total: items.length,
      critical: items.filter((d) => d.severity === 'critical').length,
      major: items.filter((d) => d.severity === 'major').length,
      minor: items.filter((d) => d.severity === 'minor').length,
    }
  })

  const status: 'PASS' | 'FAIL' = criticalCount > 0 || majorCount > 0 ? 'FAIL' : 'PASS'
  const durationMs = Math.round(performance.now() - start)

  return {
    status,
    durationMs,
    totalDiffs: diffs.length,
    criticalCount,
    majorCount,
    minorCount,
    differences: diffs,
    categories,
    master: fileMeta(masterFile.name, masterFile.size, master),
    actual: fileMeta(actualFile.name, actualFile.size, actual),
    checkedAt: new Date().toISOString(),
  }
}

export function exportDifferencesToExcel(result: CompareResult) {
  const rows = [
    ['ISO9001 Form Verification Report'],
    ['Master Form', result.master.name],
    ['Actual Form', result.actual.name],
    ['ผลการตรวจสอบ', result.status],
    ['วันที่ตรวจ', new Date(result.checkedAt).toLocaleString('th-TH')],
    ['จำนวนจุดที่ต่าง', result.totalDiffs],
    [],
    ['ลำดับ', 'หมวด', 'ระดับ', 'Sheet', 'ตำแหน่ง', 'รายการ', 'ค่าใน Master', 'ค่าใน Actual', 'รายละเอียด'],
    ...result.differences.map((d, i) => [
      i + 1,
      getCategoryLabel(d.category),
      d.severity,
      d.sheet,
      d.cell ?? '-',
      d.title,
      d.masterValue,
      d.actualValue,
      d.detail,
    ]),
  ]
  const ws = XLSX.utils.aoa_to_sheet(rows)
  ws['!cols'] = [
    { wch: 6 },
    { wch: 18 },
    { wch: 10 },
    { wch: 14 },
    { wch: 12 },
    { wch: 30 },
    { wch: 24 },
    { wch: 24 },
    { wch: 40 },
  ]
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Verification Report')
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')
  XLSX.writeFile(wb, `Form-Verification-${result.status}-${stamp}.xlsx`)
}
