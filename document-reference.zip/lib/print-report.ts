import { type CompareResult, getCategoryLabel } from './excel-compare'

const SEVERITY_TH: Record<string, string> = {
  critical: 'วิกฤต',
  major: 'สำคัญ',
  minor: 'เล็กน้อย',
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

export function openPrintableReport(result: CompareResult) {
  const win = window.open('', '_blank', 'width=900,height=1000')
  if (!win) return

  const pass = result.status === 'PASS'
  const checkedAt = new Date(result.checkedAt).toLocaleString('th-TH')
  const seconds = (result.durationMs / 1000).toFixed(2)

  const rows = result.differences
    .map(
      (d, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${escapeHtml(getCategoryLabel(d.category))}</td>
        <td class="sev sev-${d.severity}">${SEVERITY_TH[d.severity]}</td>
        <td class="mono">${escapeHtml(d.sheet)}${d.cell ? ` · ${escapeHtml(d.cell)}` : ''}</td>
        <td>
          <strong>${escapeHtml(d.title)}</strong><br/>
          <span class="detail">${escapeHtml(d.detail)}</span>
        </td>
        <td class="mono master">${escapeHtml(d.masterValue || '(ว่าง)')}</td>
        <td class="mono actual">${escapeHtml(d.actualValue || '(ว่าง)')}</td>
      </tr>`,
    )
    .join('')

  const categoryRows = result.categories
    .map(
      (c) => `<tr><td>${escapeHtml(c.label)}</td><td>${c.total}</td><td>${c.critical}</td><td>${c.major}</td><td>${c.minor}</td></tr>`,
    )
    .join('')

  const html = `<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8"/>
<title>ISO9001 Form Verification Report</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Tahoma, sans-serif; color: #1a2233; margin: 32px; font-size: 12px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .sub { color: #667; margin: 0 0 20px; font-size: 12px; }
  .status { display: inline-block; padding: 8px 20px; border-radius: 8px; font-size: 24px; font-weight: 800; letter-spacing: 1px; margin: 8px 0 16px; }
  .pass { background: #dcfce7; color: #166534; }
  .fail { background: #fee2e2; color: #b91c1c; }
  .meta { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
  .meta td { padding: 6px 10px; border: 1px solid #e2e8f0; }
  .meta td:first-child { background: #f1f5f9; font-weight: 600; width: 180px; }
  table.diff { width: 100%; border-collapse: collapse; }
  table.diff th, table.diff td { border: 1px solid #e2e8f0; padding: 6px 8px; text-align: left; vertical-align: top; }
  table.diff th { background: #1e3a5f; color: #fff; font-size: 11px; }
  .mono { font-family: 'Consolas', monospace; font-size: 11px; }
  .detail { color: #667; font-size: 11px; }
  .master { color: #1e40af; }
  .actual { color: #b91c1c; }
  .sev { font-weight: 700; }
  .sev-critical { color: #b91c1c; }
  .sev-major { color: #c2410c; }
  .sev-minor { color: #a16207; }
  h2 { font-size: 14px; margin: 24px 0 8px; border-bottom: 2px solid #1e3a5f; padding-bottom: 4px; }
  .footer { margin-top: 32px; color: #94a3b8; font-size: 10px; border-top: 1px solid #e2e8f0; padding-top: 8px; }
  @media print { body { margin: 12mm; } .no-print { display: none; } }
</style>
</head>
<body>
  <h1>ISO9001 Form Verification Report</h1>
  <p class="sub">ระบบตรวจสอบความสอดคล้องของแบบฟอร์มที่ใช้งานจริงกับแบบฟอร์มที่ขึ้นทะเบียน</p>
  <div class="status ${pass ? 'pass' : 'fail'}">${result.status}</div>

  <table class="meta">
    <tr><td>Master Form</td><td>${escapeHtml(result.master.name)}</td></tr>
    <tr><td>Actual Form</td><td>${escapeHtml(result.actual.name)}</td></tr>
    <tr><td>วันที่ตรวจสอบ</td><td>${checkedAt}</td></tr>
    <tr><td>เวลาที่ใช้ตรวจ</td><td>${seconds} วินาที</td></tr>
    <tr><td>จำนวนจุดที่แตกต่าง</td><td>${result.totalDiffs} จุด (วิกฤต ${result.criticalCount} · สำคัญ ${result.majorCount} · เล็กน้อย ${result.minorCount})</td></tr>
  </table>

  <h2>สรุปตามหมวดการตรวจ</h2>
  <table class="diff">
    <thead><tr><th>หมวด</th><th>รวม</th><th>วิกฤต</th><th>สำคัญ</th><th>เล็กน้อย</th></tr></thead>
    <tbody>${categoryRows}</tbody>
  </table>

  <h2>รายการจุดที่แตกต่าง (Difference List)</h2>
  ${
    result.differences.length === 0
      ? '<p>ไม่พบความแตกต่าง — แบบฟอร์มสอดคล้องกับ Master Form ทุกประการ</p>'
      : `<table class="diff">
    <thead><tr><th>#</th><th>หมวด</th><th>ระดับ</th><th>ตำแหน่ง</th><th>รายการ</th><th>ค่าใน Master</th><th>ค่าใน Actual</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`
  }

  <div class="footer">Registered Form Compliance Checker · QAA Kaizen Proposal · Auto-generated Audit Evidence</div>
  <script>window.onload = function(){ setTimeout(function(){ window.print(); }, 400); };</script>
</body>
</html>`

  win.document.open()
  win.document.write(html)
  win.document.close()
}
