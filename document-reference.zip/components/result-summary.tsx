'use client'

import { CheckCircle2, XCircle, Clock, FileSpreadsheet, ListChecks } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { CompareResult } from '@/lib/excel-compare'

function Stat({
  icon,
  value,
  label,
  tone = 'default',
}: {
  icon: React.ReactNode
  value: string
  label: string
  tone?: 'default' | 'fail' | 'warn'
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border bg-card p-4">
      <div
        className={cn(
          'flex size-9 shrink-0 items-center justify-center rounded-md',
          tone === 'fail' && 'bg-fail-muted text-fail',
          tone === 'warn' && 'bg-warn-muted text-warn-foreground',
          tone === 'default' && 'bg-muted text-muted-foreground',
        )}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <p className="font-mono text-lg font-semibold leading-none text-card-foreground">{value}</p>
        <p className="mt-1 truncate text-xs text-muted-foreground">{label}</p>
      </div>
    </div>
  )
}

export function ResultSummary({ result }: { result: CompareResult }) {
  const pass = result.status === 'PASS'
  const seconds = (result.durationMs / 1000).toFixed(2)

  return (
    <div className="flex flex-col gap-4">
      <div
        className={cn(
          'relative overflow-hidden rounded-xl border p-6 sm:p-8',
          pass ? 'border-pass/30 bg-pass-muted' : 'border-fail/30 bg-fail-muted',
        )}
      >
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div
              className={cn(
                'flex size-14 shrink-0 items-center justify-center rounded-full',
                pass ? 'bg-pass text-pass-foreground' : 'bg-fail text-fail-foreground',
              )}
            >
              {pass ? <CheckCircle2 className="size-8" /> : <XCircle className="size-8" />}
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                ผลการตรวจสอบ
              </p>
              <p
                className={cn(
                  'font-mono text-4xl font-bold leading-tight',
                  pass ? 'text-pass' : 'text-fail',
                )}
              >
                {result.status}
              </p>
            </div>
          </div>
          <div className="text-left sm:text-right">
            <p className="text-sm text-foreground">
              {pass
                ? 'แบบฟอร์มสอดคล้องกับ Master Form ที่ขึ้นทะเบียน'
                : `พบความไม่สอดคล้อง ${result.totalDiffs} จุด ที่ต้องแก้ไข`}
            </p>
            <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground sm:justify-end">
              <Clock className="size-3.5" />
              ตรวจเสร็จใน {seconds} วินาที
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          icon={<XCircle className="size-4" />}
          value={String(result.criticalCount)}
          label="วิกฤต (Critical)"
          tone={result.criticalCount > 0 ? 'fail' : 'default'}
        />
        <Stat
          icon={<ListChecks className="size-4" />}
          value={String(result.majorCount)}
          label="สำคัญ (Major)"
          tone={result.majorCount > 0 ? 'fail' : 'default'}
        />
        <Stat
          icon={<ListChecks className="size-4" />}
          value={String(result.minorCount)}
          label="เล็กน้อย (Minor)"
          tone={result.minorCount > 0 ? 'warn' : 'default'}
        />
        <Stat
          icon={<Clock className="size-4" />}
          value={`${seconds}s`}
          label="เวลาที่ใช้ตรวจ"
        />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="flex items-start gap-3 rounded-lg border border-border bg-card p-4">
          <FileSpreadsheet className="mt-0.5 size-5 shrink-0 text-primary" />
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary">Master Form</p>
            <p className="truncate text-sm font-medium text-card-foreground">{result.master.name}</p>
            <p className="text-xs text-muted-foreground">
              {result.master.sheetCount} sheet · {result.master.sheetNames.join(', ')}
            </p>
          </div>
        </div>
        <div className="flex items-start gap-3 rounded-lg border border-border bg-card p-4">
          <FileSpreadsheet className="mt-0.5 size-5 shrink-0 text-accent-foreground" />
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-wide text-accent-foreground">
              Actual Form
            </p>
            <p className="truncate text-sm font-medium text-card-foreground">{result.actual.name}</p>
            <p className="text-xs text-muted-foreground">
              {result.actual.sheetCount} sheet · {result.actual.sheetNames.join(', ')}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
