'use client'

import { useState } from 'react'
import { ArrowRight, Loader2, RotateCcw, FileDown, Printer, AlertTriangle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { FileDrop } from '@/components/file-drop'
import { ResultSummary } from '@/components/result-summary'
import { DifferenceList } from '@/components/difference-list'
import {
  compareWorkbooks,
  exportDifferencesToExcel,
  type CompareResult,
} from '@/lib/excel-compare'
import { openPrintableReport } from '@/lib/print-report'

export function VerificationTool() {
  const [masterFile, setMasterFile] = useState<File | null>(null)
  const [actualFile, setActualFile] = useState<File | null>(null)
  const [result, setResult] = useState<CompareResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const canCompare = Boolean(masterFile && actualFile) && !loading

  async function handleCompare() {
    if (!masterFile || !actualFile) return
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      // Small delay so the loading state is perceivable for tiny files
      await new Promise((r) => setTimeout(r, 250))
      const res = await compareWorkbooks(masterFile, actualFile)
      setResult(res)
    } catch (err) {
      console.log('[v0] compare error:', err)
      setError(
        'ไม่สามารถอ่านไฟล์ Excel ได้ กรุณาตรวจสอบว่าไฟล์ไม่เสียหายและเป็นสกุล .xlsx / .xls / .xlsm',
      )
    } finally {
      setLoading(false)
    }
  }

  function handleReset() {
    setMasterFile(null)
    setActualFile(null)
    setResult(null)
    setError(null)
  }

  return (
    <div className="flex flex-col gap-8">
      <section className="rounded-2xl border border-border bg-card/60 p-5 sm:p-6">
        <div className="mb-5 flex items-center gap-2">
          <span className="flex size-7 items-center justify-center rounded-md bg-primary font-mono text-sm font-bold text-primary-foreground">
            1
          </span>
          <h2 className="text-lg font-semibold text-foreground">อัปโหลดแบบฟอร์มเพื่อเปรียบเทียบ</h2>
        </div>

        <div className="grid grid-cols-1 items-start gap-6 md:grid-cols-[1fr_auto_1fr]">
          <FileDrop
            label="แบบฟอร์มมาตรฐาน"
            tag="Master"
            description="ไฟล์ที่ขึ้นทะเบียน ISO9001 ล่าสุด (Baseline)"
            file={masterFile}
            onFile={(f) => {
              setMasterFile(f)
              setResult(null)
            }}
            accent="master"
          />

          <div className="hidden items-center justify-center self-center pt-6 md:flex">
            <div className="flex size-9 items-center justify-center rounded-full border border-border bg-muted text-muted-foreground">
              <ArrowRight className="size-4" />
            </div>
          </div>

          <FileDrop
            label="แบบฟอร์มที่ใช้งานจริง"
            tag="Actual"
            description="ไฟล์ที่หน้างานนำไปใช้จริง เพื่อนำมาตรวจสอบ"
            file={actualFile}
            onFile={(f) => {
              setActualFile(f)
              setResult(null)
            }}
            accent="actual"
          />
        </div>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
          <Button
            type="button"
            onClick={handleCompare}
            disabled={!canCompare}
            size="lg"
            className="w-full sm:w-auto"
          >
            {loading ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                กำลังตรวจสอบ...
              </>
            ) : (
              <>เปรียบเทียบและตรวจสอบ</>
            )}
          </Button>
          {(masterFile || actualFile || result) && (
            <Button
              type="button"
              variant="outline"
              size="lg"
              onClick={handleReset}
              className="w-full sm:w-auto"
            >
              <RotateCcw className="size-4" />
              เริ่มใหม่
            </Button>
          )}
        </div>

        {error ? (
          <div className="mt-4 flex items-start gap-2 rounded-lg border border-fail/30 bg-fail-muted p-3 text-sm text-fail">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            <span>{error}</span>
          </div>
        ) : null}
      </section>

      {result ? (
        <section className="flex flex-col gap-6">
          <div className="flex items-center gap-2">
            <span className="flex size-7 items-center justify-center rounded-md bg-primary font-mono text-sm font-bold text-primary-foreground">
              2
            </span>
            <h2 className="text-lg font-semibold text-foreground">ผลการตรวจสอบและหลักฐาน</h2>
          </div>

          <ResultSummary result={result} />

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button type="button" variant="outline" onClick={() => openPrintableReport(result)}>
              <Printer className="size-4" />
              พิมพ์รายงาน / บันทึกเป็น PDF
            </Button>
            <Button type="button" variant="outline" onClick={() => exportDifferencesToExcel(result)}>
              <FileDown className="size-4" />
              Export เป็น Excel (Evidence)
            </Button>
          </div>

          <DifferenceList result={result} />
        </section>
      ) : null}
    </div>
  )
}
