'use client'

import { useMemo, useState } from 'react'
import { CheckCircle2, ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { CompareResult, Difference, Severity, Category } from '@/lib/excel-compare'

const SEVERITY_META: Record<Severity, { label: string; className: string }> = {
  critical: { label: 'วิกฤต', className: 'bg-fail text-fail-foreground' },
  major: { label: 'สำคัญ', className: 'bg-fail-muted text-fail border border-fail/30' },
  minor: { label: 'เล็กน้อย', className: 'bg-warn-muted text-warn-foreground border border-warn/30' },
}

function SeverityBadge({ severity }: { severity: Severity }) {
  const meta = SEVERITY_META[severity]
  return (
    <span
      className={cn(
        'inline-flex shrink-0 items-center rounded px-2 py-0.5 text-xs font-semibold',
        meta.className,
      )}
    >
      {meta.label}
    </span>
  )
}

function DiffRow({ diff }: { diff: Difference }) {
  return (
    <div className="flex flex-col gap-3 border-b border-border p-4 last:border-b-0 sm:flex-row sm:items-start">
      <div className="flex items-center gap-2 sm:w-40 sm:shrink-0 sm:flex-col sm:items-start">
        <SeverityBadge severity={diff.severity} />
        <span className="font-mono text-xs text-muted-foreground">
          {diff.sheet}
          {diff.cell ? ` · ${diff.cell}` : ''}
        </span>
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-card-foreground">{diff.title}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">{diff.detail}</p>
        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
          <span className="rounded bg-primary/10 px-2 py-1 font-mono text-primary">
            {diff.masterValue || '(ว่าง)'}
          </span>
          <ArrowRight className="size-3.5 text-muted-foreground" />
          <span className="rounded bg-fail-muted px-2 py-1 font-mono text-fail">
            {diff.actualValue || '(ว่าง)'}
          </span>
        </div>
      </div>
    </div>
  )
}

export function DifferenceList({ result }: { result: CompareResult }) {
  const [active, setActive] = useState<Category | 'all'>('all')

  const filtered = useMemo(
    () =>
      active === 'all'
        ? result.differences
        : result.differences.filter((d) => d.category === active),
    [active, result.differences],
  )

  const availableCategories = result.categories.filter((c) => c.total > 0)

  if (result.differences.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-pass/30 bg-pass-muted p-10 text-center">
        <CheckCircle2 className="size-10 text-pass" />
        <p className="text-lg font-semibold text-foreground">ไม่พบความแตกต่าง</p>
        <p className="max-w-md text-sm text-muted-foreground">
          แบบฟอร์มที่ใช้งานจริงมีโครงสร้าง สูตร ข้อมูลควบคุม และ Layout ตรงกับ Master Form
          ที่ขึ้นทะเบียนทุกประการ
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="text-lg font-semibold text-foreground">รายการจุดที่แตกต่าง (Difference List)</h2>
        <p className="text-sm text-muted-foreground">
          ระบุตำแหน่งและรายละเอียดที่ไม่สอดคล้องกับ Master Form
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setActive('all')}
          className={cn(
            'rounded-full border px-3 py-1.5 text-xs font-medium transition-colors',
            active === 'all'
              ? 'border-primary bg-primary text-primary-foreground'
              : 'border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground',
          )}
        >
          ทั้งหมด ({result.differences.length})
        </button>
        {availableCategories.map((c) => (
          <button
            key={c.key}
            type="button"
            onClick={() => setActive(c.key)}
            className={cn(
              'rounded-full border px-3 py-1.5 text-xs font-medium transition-colors',
              active === c.key
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground',
            )}
          >
            {c.label} ({c.total})
          </button>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        {filtered.map((diff) => (
          <DiffRow key={diff.id} diff={diff} />
        ))}
      </div>
    </div>
  )
}
