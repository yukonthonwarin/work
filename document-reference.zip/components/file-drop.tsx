'use client'

import { useRef, useState, type DragEvent } from 'react'
import { FileSpreadsheet, Upload, X, CheckCircle2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface FileDropProps {
  label: string
  tag: string
  description: string
  file: File | null
  onFile: (file: File | null) => void
  accent: 'master' | 'actual'
}

const ACCEPTED = ['.xlsx', '.xls', '.xlsm']

function isAccepted(name: string) {
  return ACCEPTED.some((ext) => name.toLowerCase().endsWith(ext))
}

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}

export function FileDrop({ label, tag, description, file, onFile, accent }: FileDropProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragOver, setDragOver] = useState(false)
  const [error, setError] = useState<string | null>(null)

  function handleFiles(files: FileList | null) {
    setError(null)
    const f = files?.[0]
    if (!f) return
    if (!isAccepted(f.name)) {
      setError('รองรับเฉพาะไฟล์ Excel (.xlsx, .xls, .xlsm)')
      return
    }
    onFile(f)
  }

  function onDrop(e: DragEvent<HTMLDivElement>) {
    e.preventDefault()
    setDragOver(false)
    handleFiles(e.dataTransfer.files)
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <span
          className={cn(
            'inline-flex items-center rounded-md px-2 py-0.5 font-mono text-xs font-semibold uppercase tracking-wide',
            accent === 'master'
              ? 'bg-primary/10 text-primary'
              : 'bg-accent text-accent-foreground',
          )}
        >
          {tag}
        </span>
        <span className="text-sm font-medium text-foreground">{label}</span>
      </div>

      {file ? (
        <div className="flex items-center gap-3 rounded-lg border border-border bg-card p-4">
          <div
            className={cn(
              'flex size-10 shrink-0 items-center justify-center rounded-md',
              accent === 'master' ? 'bg-primary/10 text-primary' : 'bg-accent text-accent-foreground',
            )}
          >
            <FileSpreadsheet className="size-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-card-foreground">{file.name}</p>
            <p className="text-xs text-muted-foreground">{formatSize(file.size)}</p>
          </div>
          <CheckCircle2 className="size-5 shrink-0 text-pass" aria-hidden />
          <button
            type="button"
            onClick={() => {
              onFile(null)
              setError(null)
              if (inputRef.current) inputRef.current.value = ''
            }}
            className="rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            aria-label={`ลบไฟล์ ${label}`}
          >
            <X className="size-4" />
          </button>
        </div>
      ) : (
        <div
          role="button"
          tabIndex={0}
          onClick={() => inputRef.current?.click()}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault()
              inputRef.current?.click()
            }
          }}
          onDragOver={(e) => {
            e.preventDefault()
            setDragOver(true)
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          className={cn(
            'flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-6 text-center transition-colors',
            dragOver
              ? 'border-primary bg-primary/5'
              : 'border-border bg-card hover:border-primary/50 hover:bg-muted/40',
          )}
        >
          <div className="flex size-10 items-center justify-center rounded-full bg-muted text-muted-foreground">
            <Upload className="size-5" />
          </div>
          <p className="text-sm font-medium text-foreground">
            ลากไฟล์มาวาง หรือคลิกเพื่อเลือก
          </p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      )}

      {error ? <p className="text-xs font-medium text-fail">{error}</p> : null}

      <input
        ref={inputRef}
        type="file"
        accept=".xlsx,.xls,.xlsm"
        className="sr-only"
        onChange={(e) => handleFiles(e.target.files)}
      />
    </div>
  )
}
