import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Sarabun, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const sarabun = Sarabun({
  subsets: ['latin', 'thai'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sarabun',
  display: 'swap',
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'ISO9001 Form Verification | ระบบตรวจสอบความสอดคล้องแบบฟอร์ม',
  description:
    'ตรวจสอบความถูกต้องของแบบฟอร์มที่ใช้งานจริง โดยเปรียบเทียบกับแบบฟอร์มมาตรฐานที่ขึ้นทะเบียน ISO9001 พร้อมผล PASS / FAIL และรายงานหลักฐานสำหรับ Audit',
  generator: 'v0.app',
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f3f5f8' },
    { media: '(prefers-color-scheme: dark)', color: '#1a2233' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="th" className={`bg-background ${sarabun.variable} ${jetbrainsMono.variable}`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
