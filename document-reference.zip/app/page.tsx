import {
  ShieldCheck,
  Layers,
  KeyRound,
  Sigma,
  LayoutGrid,
  FileText,
  Timer,
  ClipboardCheck,
} from 'lucide-react'
import { VerificationTool } from '@/components/verification-tool'

const CHECK_ITEMS = [
  {
    icon: Layers,
    title: 'โครงสร้างไฟล์',
    desc: 'ชื่อ Sheet, จำนวน Sheet, จำนวน Row / Column และ Merged cell',
  },
  {
    icon: KeyRound,
    title: 'ข้อมูลสำคัญ',
    desc: 'Form No., Revision, Effective date และ Header / Footer',
  },
  {
    icon: Sigma,
    title: 'สูตรคำนวณ',
    desc: 'Formula ในเซลล์สำคัญและสูตรรวม ป้องกันผลคำนวณคลาดเคลื่อน',
  },
  {
    icon: LayoutGrid,
    title: 'Layout / ตำแหน่ง',
    desc: 'ตำแหน่งตาราง ช่องกรอก ลายเซ็น และพื้นที่ควบคุม',
  },
  {
    icon: FileText,
    title: 'ข้อความในแบบฟอร์ม',
    desc: 'ข้อความตายตัวและหัวข้อ ที่ต้องตรงกับต้นฉบับที่ขึ้นทะเบียน',
  },
]

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-4 sm:px-6">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <ShieldCheck className="size-5" />
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight text-foreground">
              Registered Form Compliance Checker
            </p>
            <p className="font-mono text-xs uppercase tracking-wide text-muted-foreground">
              ISO9001 · Form Control · QAA Kaizen
            </p>
          </div>
        </div>
      </header>

      <section className="border-b border-border">
        <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 font-mono text-xs text-muted-foreground">
            <Timer className="size-3.5" />
            Phase 1 · Excel Form Compare
          </span>
          <h1 className="mt-4 max-w-3xl text-balance text-3xl font-bold leading-tight text-foreground sm:text-4xl">
            ระบบตรวจสอบความสอดคล้องของแบบฟอร์มที่ใช้งานจริงกับแบบฟอร์มที่ขึ้นทะเบียน
          </h1>
          <p className="mt-3 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground">
            เปลี่ยนจากการตรวจด้วยสายตา (Manual Check) เป็นการตรวจแบบอัตโนมัติ (Auto Verification)
            โดยเปรียบเทียบ Master Form กับ Actual Form เพื่อป้องกันการใช้แบบฟอร์มผิด Revision
            หรือถูกแก้ไขโดยไม่ได้รับอนุมัติ พร้อมสร้างหลักฐานสำหรับ Audit
          </p>

          <dl className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-border bg-card p-4">
              <dt className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                <ClipboardCheck className="size-4 text-primary" />
                เป้าหมายการตรวจ
              </dt>
              <dd className="mt-1 font-mono text-xl font-bold text-foreground">PASS / FAIL</dd>
            </div>
            <div className="rounded-xl border border-border bg-card p-4">
              <dt className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                <Timer className="size-4 text-primary" />
                เวลาเป้าหมาย
              </dt>
              <dd className="mt-1 font-mono text-xl font-bold text-foreground">&lt; 30 sec</dd>
            </div>
            <div className="rounded-xl border border-border bg-card p-4">
              <dt className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                <FileText className="size-4 text-primary" />
                หลักฐาน
              </dt>
              <dd className="mt-1 font-mono text-xl font-bold text-foreground">Auto Report</dd>
            </div>
          </dl>
        </div>
      </section>

      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <VerificationTool />

        <section className="mt-14">
          <div className="mb-5">
            <h2 className="text-lg font-semibold text-foreground">รายการที่ระบบตรวจสอบ</h2>
            <p className="text-sm text-muted-foreground">
              ระบบเปรียบเทียบข้อมูลสำคัญของแบบฟอร์มแบบอัตโนมัติในทุกครั้งที่ตรวจ
            </p>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CHECK_ITEMS.map((item) => {
              const Icon = item.icon
              return (
                <div
                  key={item.title}
                  className="flex gap-3 rounded-xl border border-border bg-card p-4"
                >
                  <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <Icon className="size-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-card-foreground">{item.title}</p>
                    <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                      {item.desc}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        </section>
      </div>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-5xl px-4 py-6 text-xs text-muted-foreground sm:px-6">
          QAA Kaizen Proposal · ISO9001 Form Control · การประมวลผลทั้งหมดทำงานภายในเบราว์เซอร์
          ไฟล์ของคุณไม่ถูกอัปโหลดออกไปที่ใด
        </div>
      </footer>
    </main>
  )
}
